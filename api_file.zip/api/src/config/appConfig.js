'use strict';

module.exports = [
  {
    appInfo: {
      name: "Service Management System",
      ports: {
        dev: 9991,
        prod: 9992
      }
    }
  }
];