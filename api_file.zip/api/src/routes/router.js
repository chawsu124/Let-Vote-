const Router = require('koa-router');

// import router files
const indexRoutes = require('./index');
const positionRoutes = require('./position-router');
const stateDivisionRoutes = require('./state-division-router');
const districtRoutes = require('./district-router');
const townshipRoutes = require('./township-router');
const studentRoutes = require('./student-router');
const teacherRoutes = require('./teacher-router');

const router = new Router({ prefix: '/api/v1'});

// use router files
router.use(indexRoutes.routes(), router.allowedMethods());
router.use(positionRoutes.routes(), router.allowedMethods());
router.use(stateDivisionRoutes.routes(), router.allowedMethods());
router.use(districtRoutes.routes(), router.allowedMethods());
router.use(townshipRoutes.routes(), router.allowedMethods());
router.use(studentRoutes.routes(), router.allowedMethods());
router.use(teacherRoutes.routes(), router.allowedMethods());

module.exports = router;