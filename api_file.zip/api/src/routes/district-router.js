var Router = require('koa-router');
var router = new Router();

var districtQuery = require('../services/district');


router.get('/district', async(ctx) => {
    var list = await districtQuery.getAllDistrict()
    try {
        ctx.body = {
            status: 200,
            data: list
        }
    } catch (error) {
        ctx.body = {
            status: 400, 
            data: error.message
        }
    }
    
});

router.get('/district', async(ctx) => {
    var id= ctx.params.id
    var data = await districtQuery.getDistrictById(id)
    try {
        ctx.body = {
            status: 200,
            data: list
        }
    } catch (error) {
        ctx.body= {
            status: 400,
            data:error.message
        }
    }
});

module.exports = router;
