var Router = require('koa-router');
var router = new Router();
var stateDivisionQuery = require('../services/state-division');

router.get('/state_division', async(ctx) => {
    var list = await stateDivisionQuery.getAllStateDivision()
    try {
        ctx.body = {
            status: 200,
            data: list
        }
    } catch (error) {
        ctx.body= {
            status: 400,
            data:error.message
        }
    }
});

router.get('/state_division/:id', async(ctx) => {
    var id = ctx.params.id;
    // console.log(id, "id")
    var data = await stateDivisionQuery.getStateDivisionById(id)
    try {
        ctx.body = {
            status: 200,
            data: data
        }
    } catch (error) {
        ctx.body = {
            status :400,
            data: error.message
        }
    }

})

module.exports = router;