var Router = require('koa-router');
var router = new Router();

router.get('/township',(ctx) => {
    ctx.body = "Township"
})

module.exports = router;