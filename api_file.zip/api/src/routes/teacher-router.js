var Router = require('koa-router');
var router = new Router();

router.get('/teacher',(ctx) => {
    ctx.body = "Teacher"
})

module.exports = router;