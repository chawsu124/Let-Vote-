var Router = require('koa-router');
var router = new Router();

router.get('/student',(ctx) => {
    ctx.body = "Student"
})

module.exports = router;