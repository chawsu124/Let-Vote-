const position_data = [
	{	
		id: 1,
		name: 'Position 1', 
		description: 'testing', 
		created_by : 'Admini',
		updated_by : 'Admin',
		status: 'Active'
	},
	{
		id: 2, 
		name: 'Position 2', 
		description: 'testing', 
		created_by : 'Admini',
		updated_by : 'Admin',
		status: 'Active'
	},
	{	
		id: 3, 
		name: 'Position 3', 
		description: 'testing', 
		created_by : 'Admini',
		updated_by : 'Admin',
		status: 'Active'
	}
];

exports.seed = function(knex, Promise) {
  
  return knex('position').del()
    .then(function () {
      return knex('position').insert(position_data);
    });
};