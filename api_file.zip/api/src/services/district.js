var knex = require('../db/connection')

function getAllDistrict(){
    return knex.raw('select * from district').then(res => res[0])
}

function getDistrictById(id){
    return knex.raw('select * from district where id = ?', [id]).then(res => res[0][0])

}

module.exports = {
    getAllDistrict,
    getDistrictById
}