var knex = require('../db/connection');

function getAllStateDivision(){
    return knex.raw('select * from state_division').then((res) => res[0])
}

function getStateDivisionById(id){
    return knex.raw('select * from state_division where id = ?',
    [id]).then(res=> res[0][0])
}

module.exports= {
    getAllStateDivision, 
    getStateDivisionById
}